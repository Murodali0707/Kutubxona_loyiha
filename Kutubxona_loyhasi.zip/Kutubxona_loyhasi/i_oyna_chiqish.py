import sys
from PyQt5.QtWidgets import QApplication, QWidget, QPushButton, QVBoxLayout

class ExitOyna(QWidget):
    def __init__(self):
        super().__init__()

        self.init_ui()

    def init_ui(self):
        exit_tugmasi = QPushButton('Chiqish', self)
        exit_tugmasi.clicked.connect(self.exit_funksiya)

        qaytish_tugmasi = QPushButton('Qaytish', self)
        qaytish_tugmasi.clicked.connect(self.qaytish_funksiya)

        qurilma_tizma = QVBoxLayout()
        qurilma_tizma.addWidget(exit_tugmasi)
        qurilma_tizma.addWidget(qaytish_tugmasi)

        self.setLayout(qurilma_tizma)

        self.setGeometry(300, 300, 300, 150)
        self.setWindowTitle('Exit va Qaytish Oynasi')
        self.show()

    def exit_funksiya(self, qApp=None):
        qApp.quit()

    def qaytish_funksiya(self):
        self.close()

if __name__ == '__main__':
    app = QApplication(sys.argv)
    oyna = ExitOyna()
    sys.exit(app.exec_())