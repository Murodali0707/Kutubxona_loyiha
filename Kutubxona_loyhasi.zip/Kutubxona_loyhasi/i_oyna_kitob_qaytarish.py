import sys
from PyQt5.QtWidgets import QApplication, QWidget, QPushButton, QLabel, QLineEdit


class KitobQaytarishOyna(QWidget):
    def __init__(self):
        super().__init__()

        self.initUI()

    def initUI(self):
        self.kitob_id_label = QLabel("Kitob IDsi:", self)
        self.kitob_id_label.setGeometry(50, 50, 100, 30)
        self.kitob_id_input = QLineEdit(self)
        self.kitob_id_input.setGeometry(150, 50, 200, 30)

        self.talaba_id_label = QLabel("Talaba IDsi:", self)
        self.talaba_id_label.setGeometry(50, 90, 100, 30)
        self.talaba_id_input = QLineEdit(self)
        self.talaba_id_input.setGeometry(150, 90, 200, 30)

        self.qaytarish_oyna = QLabel(self)
        self.qaytarish_oyna.setText("Kitobni qaytarish uchun 'OK' tugmasini bosing.")
        self.qaytarish_oyna.setGeometry(50, 130, 300, 50)

        self.ok_tugma = QPushButton("OK", self)
        self.ok_tugma.setGeometry(150, 190, 100, 50)
        self.ok_tugma.clicked.connect(self.qaytarish)

        self.setGeometry(300, 300, 400, 300)
        self.setWindowTitle("Kitobni Qaytarish Oynasi")
        self.show()

    def qaytarish(self):
        kitob_id = self.kitob_id_input.text()
        talaba_id = self.talaba_id_input.text()
        self.qaytarish_oyna.setText(f"Kitob qaytarildi. Rahmat!")


if __name__ == "__main__":
    app = QApplication(sys.argv)
    oyna = KitobQaytarishOyna()
    sys.exit(app.exec_())