import sys
from PyQt5.QtWidgets import QApplication, QWidget, QPushButton, QLabel, QLineEdit, QVBoxLayout, QMainWindow, \
    QTableWidget, QTableWidgetItem
import mysql.connector


class oquvchilar(QMainWindow):
    def __init__(self):
        super().__init__()

        self.setWindowTitle("O'quvchilar")
        self.setGeometry(100, 100, 800, 600)

        self.central_widget = QWidget()
        self.setCentralWidget(self.central_widget)

        self.init_ui()

    def init_ui(self):
        self.table = QTableWidget()
        self.central_layout = QVBoxLayout(self.central_widget)
        self.central_layout.addWidget(self.table)

        self.load_data()

    def load_data(self):
        # MySQL connection sozlamalari
        db_config = {
            'host': 'localhost',
            'user': 'root',
            'password': '07072004ms',
            'database': 'kutubxona',
            'raise_on_warnings': True
        }

        try:
            # MySQLga ulanish
            connection = mysql.connector.connect(**db_config)
            cursor = connection.cursor()

            # MySQL-query
            query = "SELECT * FROM oquvchilar"
            cursor.execute(query)

            # Natijalarni olish
            result = cursor.fetchall()

            # Tableni tozalash
            self.table.setRowCount(0)
            self.table.setColumnCount(len(result[0]))

            # Tableni to'ldirish
            for row_num, row_data in enumerate(result):
                self.table.insertRow(row_num)
                for col_num, col_data in enumerate(row_data):
                    self.table.setItem(row_num, col_num, QTableWidgetItem(str(col_data)))

        except mysql.connector.Error as err:
            print(f"Xatolik: {err}")

        finally:
            # Ulanishni yopish
            if 'connection' in locals() and connection.is_connected():
                cursor.close()
                connection.close()

if __name__ == '__main__':
    app = QApplication(sys.argv)
    window = oquvchilar()
    window.show()
    sys.exit(app.exec_())