import sys
from PyQt5.QtWidgets import QApplication, QWidget, QPushButton, QLabel, QLineEdit, QVBoxLayout, QMainWindow
import mysql.connector
import i_oyna_kitob, i_oyna_oquvchilar,i_oyna_chiqish,i_oyna_kitob_berish,i_oyna_kitob_qaytarish, i_oyna_admin

class asosiy_oyna(QMainWindow):
    def __init__(self):
        self.window=None
        self.window1=None
        self.window2=None
        self.window4=None
        self.window5=None
        self.window6=None
        self.window7=None
        super().__init__()
        ver1 = QVBoxLayout()
        tugma1 = QPushButton("Kitob ro'yxati")
        tugma2 = QPushButton("O'quvchilar")
        tugma4 = QPushButton("Kitob olish")
        tugma5 = QPushButton("Kitob qaytarish")
        tugma6 = QPushButton("Admin panel")
        tugma7 = QPushButton("Chiqish")

        ver1.addWidget(tugma1)
        ver1.addWidget(tugma2)
        ver1.addWidget(tugma4)     
        ver1.addWidget(tugma5)
        ver1.addWidget(tugma6)
        ver1.addWidget(tugma7)
        tugma1.clicked.connect(self.kitob_list)
        tugma2.clicked.connect(self.oquvchi_list)
        tugma4.clicked.connect(self.olish)
        tugma5.clicked.connect(self.qaytarish)
        tugma6.clicked.connect(self.admin_panel)
        tugma7.clicked.connect(self.chiqish)
        self.asosiy = QWidget()
        self.asosiy.setLayout(ver1)
        self.setCentralWidget(self.asosiy)

    def kitob_list(self):
        self.window = i_oyna_kitob.Kitob()
        self.window.show()

    def oquvchi_list(self):
        self.window1 = i_oyna_oquvchilar.oquvchilar()
        self.window1.show()

    def chiqish(self):
        self.window7 = i_oyna_chiqish.ExitOyna()
        self.window7.show()


    def olish(self):
        self.window4 = i_oyna_kitob_berish.KitobOlishOyna()
        self.window4.show()

    def qaytarish(self):
        self.window5 = i_oyna_kitob_qaytarish.KitobQaytarishOyna()
        self.window5.show()


    def admin_panel(self):
        self.window6 = i_oyna_admin.AdminPanel()
        self.window6.show()


app = QApplication([])
m = asosiy_oyna()
m.show()

app.exec()