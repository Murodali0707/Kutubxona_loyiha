from b_oyna import asosiy_oyna


n = asosiy_oyna()
n.show()
