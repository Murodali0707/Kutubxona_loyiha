import sys
from PyQt5.QtWidgets import QApplication, QWidget, QLabel, QLineEdit, QPushButton, QVBoxLayout, QMessageBox,QMainWindow

class AdminPanel(QWidget):
    def __init__(self):
        super().__init__()

        self.setWindowTitle('Admin Paneli')
        self.setGeometry(100, 100, 400, 200)

        self.init_ui()

    def init_ui(self):
        self.username_label = QLabel('Username:')
        self.username_input = QLineEdit(self)

        self.password_label = QLabel('Password:')
        self.password_input = QLineEdit(self)
        self.password_input.setEchoMode(QLineEdit.Password)

        self.login_button = QPushButton('Login', self)
        self.login_button.clicked.connect(self.check_login)

        layout = QVBoxLayout()
        layout.addWidget(self.username_label)
        layout.addWidget(self.username_input)
        layout.addWidget(self.password_label)
        layout.addWidget(self.password_input)
        layout.addWidget(self.login_button)

        self.setLayout(layout)

    def check_login(self):
        username = self.username_input.text()
        password = self.password_input.text()

        if username == 'topibol' and password == 'admin123':
            QMessageBox.information(self, 'Success', """Login To'gri kiritildi\nQolgani yoq iltimos yana urinib kirib yurmang""")
        else:
            QMessageBox.warning(self, 'Error', 'Invalid username or password')

if __name__ == '__main__':
    app = QApplication(sys.argv)
    admin_panel = AdminPanel()
    admin_panel.show()
    sys.exit(app.exec_())